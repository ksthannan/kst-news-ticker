jQuery(document).ready(function(){

	jQuery('#webTicker').webTicker({

		startEmpty: false,

	});


  });